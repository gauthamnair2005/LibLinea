# The Linea Core Library

The Linea Programming Language Core Library

## What's new in Linea 2.0 'Coconut'?

* Revaped functions.
* New syntax for functions and methods.
* Included math and weblet libraries.
